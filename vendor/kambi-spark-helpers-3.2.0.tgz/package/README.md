# Spark Helpers

This package contains helper components, utilities and AI resources for the Spark Design System.

## Features

- Uses [optimized ESM imports](./docs/ESM_IMPORTS.md) for Material UI components
- Supports both ESM and CommonJS usage
- Fully tree-shakable when used with modern bundlers

## Components

- [AppLayout](./components/AppLayout/README.md) - A flexible and customizable layout component for React applications using the Spark Design System.

- [Splitter](./components/Splitter/README.md) - A helper component for creating resizable split views in React applications, compatible with the Spark Design System and Material UI v7.

- [ThemeOverride](./components/ThemeOverride/README.md) - A component that provides a flexible way to override or modify the current theme mode for a component subtree in a Material UI application.

- [TopAppBar](./components/TopAppBar/README.md) - A helper component for visually designing the `TopAppBar` slot content of `AppLayout` in the UXPin Merge tool.

## Github Copilot Upgrade & Automation Prompts

This repository includes GitHub Copilot / automation prompt files to streamline common upgrade tasks. You can use these prompt descriptors with a compatible AI agent workflow (for example, invoking a "Run Prompt" or "Copilot Task" action in your editor or CI tooling) to guide a phased, verifiable upgrade.

| Prompt | Path | Purpose |
| ------ | ---- | ------- |
| Spark → MUI Upgrade | `.github/prompts/web-upgrade-spark.prompt.md` | Migrates legacy `@kambi/spark` and `@kambi/react-picker` usage to MUI v7 and MUI X v8, integrates `@kambi/spark-design-tokens` theming (`getMUIThemeOptions`), and ensures ESM import optimization. |
| Node Active LTS Upgrade | `.github/prompts/web-upgrade-node.prompt.md` | Creates phased instructions (tooling, libraries, testing, React 17→18→19) to upgrade the project to the current Node.js Active LTS version, optionally adding an `.nvmrc` for version pinning. |

### How to Use the Prompts

1. Open the prompt file you want to execute (see paths above).
2. Initiate your AI agent / Copilot task runner pointing at the file (many setups allow a command like "Run Prompt" when the file is open).
3. Follow the generated plan. Each phase should:
   - Adjust dependencies / code per instructions
   - Re-run build, type-check, lint, and (if present) tests
4. Commit after each successful phase to keep changes reviewable.

### Tips

- Run the Spark → MUI upgrade before (or in parallel with) a Node version bump only if the tooling supports the target Node version; otherwise stabilize Node first.
- Keep commits small: one phase or logical sub-step per commit.
- If you introduce an `.nvmrc`, communicate the new Node requirement in the CHANGELOG.

If you enhance these prompts (e.g., add additional validation steps or scripts), keep them idempotent and document any new prerequisites here.

### Recommended: MUI MCP (Model Context Protocol)

Material UI provides an official MCP server (`@mui/mcp`) that lets AI assistants pull authoritative, up-to-date docs and component source snippets instead of hallucinating references.

Resources: <https://mui.com/material-ui/getting-started/mcp/>

Key benefits:

- Answers cite real MUI docs and registry code
- Reduces hallucinated links / outdated API usage
- Enables multi-step doc retrieval tools (e.g. `useMuiDocs`, `fetchDocs`)

Typical VS Code user configuration snippet (settings.json):

```jsonc
"mcp": {
   "servers": {
      "mui-mcp": {
         "type": "stdio",
         "command": "npx",
         "args": ["-y", "@mui/mcp@latest"]
      }
   }
},
"chat.mcp.enabled": true,
"chat.mcp.discovery.enabled": true
```

Rule example (place in `AGENTS.md` - [read more](https://agents.md/)) to encourage tool usage:

```markdown
## Use the mui-mcp server for any MUI questions

1. Call the "useMuiDocs" tool for the primary package
2. Call "fetchDocs" for any additional linked sections
3. Repeat until relevant APIs are fully covered
4. Answer using only fetched authoritative sources
```

Troubleshooting: If the server won't connect, run the MCP inspector (`npx @modelcontextprotocol/inspector`) and connect with command `npx -y @mui/mcp@latest` via stdio.
