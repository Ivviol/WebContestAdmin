# design-spark-design-tokens

Design tokens of Spark Design System.

## Peer dependency

MUI v6 or v7

```
"@mui/material": "^6.1.0 || ^7.1.0"
```

## Installation

```bash
npm install @kambi/spark-design-tokens
```

### Note

For MUI v5 support use [v1.3.0](https://github.com/kambi-sports-solutions/design-spark-design-tokens/tree/v1.3.0)

```bash
npm install @kambi/spark-design-tokens@^1.3.0
```

## API

### getMUIThemeOptions

`function getMUIThemeOptions(): ThemeOptions`

Returns the Material-UI theme options for dark and light themes.

**Params:**

`@param {object} options` The options for generating the theme (optional).

`@param {string} [options.theme='kambi']` Theme variant to use ('kambi' or 'tzeract').

`@param {ThemeOptions} [options.extendedThemeOptions]` Additional theme options to merge into default options.
See [Theme configuration variables](https://mui.com/material-ui/customization/theming/#theme-configuration-variables)

Note: to add extra tokens to the palette define `options.extendedThemeOptions.colorSchemes`.
See [Adding new theme tokens](https://mui.com/material-ui/customization/css-theme-variables/usage/#adding-new-theme-tokens)

**Returns:**

`@returns {ThemeOptions} The generated theme options.`

---
## Usage with MUI ThemeProvider

Use [ThemeProvider](https://mui.com/material-ui/customization/theming/#theme-provider) to inject a custom theme into your application.

ThemeProvider relies on the context feature of React to pass the theme down to the components, so you need to make sure that ThemeProvider is a parent of the components using MUI Theme.

ThemeProvider takes a theme prop and applies it to the entire React tree that it is wrapping around. It should preferably be used at the root of your component tree.

### Overriding the default theme mode
The default theme mode is set to "system" and gets stored in the local storage upon first application run.

To change the default mode:

- set the `defaultMode` property of the `ThemeProvider`

  ```js
  const options = getMUIThemeOptions();
  const theme = createTheme(options);

  return (
    <ThemeProvider theme={theme} defaultMode='light'>
  )
  ```
- clear browser localstorage in settings or DevTools console ( `localStorage.clear()` )
- refresh the page

---

## Example 1 (MUI / React / Webpack)

```js
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import '@fontsource/material-icons';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { getMUIThemeOptions } from '@kambi/spark-design-tokens';

function App() {
  // Use default 'kambi' theme
  const options = getMUIThemeOptions();
  // Or specify a theme variant
  // const options = getMUIThemeOptions({ theme: 'tzeract' });
  const theme = createTheme(options);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline enableColorScheme />
      {...}
    </ThemeProvider>
  );
}
```
For full implementation check [react-webpack](https://github.com/kambi-sports-solutions/design-spark-code-patterns/tree/main/app-scaffolds/react-webpack) Spark app scaffold.

## Example 2 (MUI / Next.js)

```js
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { getMUIThemeOptions } from '@kambi/spark-design-tokens';
import { Roboto } from 'next/font/google';

const roboto = Roboto({
  weight: ['300', '400', '500', '700'],
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-roboto',
});

function App() {
  const options = getMUIThemeOptions({
    extendedThemeOptions: {
      typography: {
        fontFamily: 'var(--font-roboto)'
      }
    }
  });
  const theme = createTheme(options);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline enableColorScheme />
      {...}
    </ThemeProvider>
  );
}
```
For full implementation check [nextjs](https://github.com/kambi-sports-solutions/design-spark-code-patterns/tree/main/app-scaffolds/nextjs) Spark app scaffold.

## Example 3 (MUI / Next.js with extended theme options providing custom palette tokens)

```js
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { getMUIThemeOptions } from '@kambi/spark-design-tokens';
import { Roboto } from 'next/font/google';

const roboto = Roboto({
  weight: ['300', '400', '500', '700'],
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-roboto',
});

function App() {
  const options = getMUIThemeOptions({
    theme: 'tzeract', // Using tzeract theme variant
    extendedThemeOptions: {
      typography: {
        fontFamily: 'var(--font-roboto)',
      },
      colorSchemes: {
        light: {
          palette: {
            myCustomToken: '#010101'
          }
        },
        dark: {
          palette: {
            myCustomToken: '#333333'
          }
        }
      }
    }
  });
  const theme = createTheme(options);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline enableColorScheme />
      {...}
    </ThemeProvider>
  );
}
```
